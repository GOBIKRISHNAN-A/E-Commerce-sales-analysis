import pandas as pd

# Load cleaned dataset
df = pd.read_csv("../cleaned_data/cleaned_superstore.csv")

# Convert date columns
df["Order Date"] = pd.to_datetime(df["Order Date"])
df["Ship Date"] = pd.to_datetime(df["Ship Date"])

# Create new columns
df["Year"] = df["Order Date"].dt.year
df["Month"] = df["Order Date"].dt.month_name()
df["Quarter"] = df["Order Date"].dt.quarter

# Create Profit Margin
df["Profit Margin"] = (df["Profit"] / df["Sales"]) * 100
df["Profit Margin"] = df["Profit Margin"].round(2)

# Display new columns
print(df[["Order Date", "Year", "Month", "Quarter", "Profit Margin"]].head())

# Save updated dataset
df.to_csv("../cleaned_data/feature_engineered_superstore.csv", index=False)

print("Feature Engineered Dataset Saved Successfully!")