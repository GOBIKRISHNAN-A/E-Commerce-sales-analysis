import pandas as pd

# Load the dataset
df = pd.read_csv("../data/Sample - Superstore.csv", encoding="latin1")

# Show first 5 rows
print(df.head())

# Dataset information
print("\nDataset Information:")
print(df.info())

# Shape
print("\nShape:")
print(df.shape)

# Column names
print("\nColumns:")
print(df.columns)

# Missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Duplicate rows
print("\nDuplicate Rows:")
print(df.duplicated().sum())

# Data types
print("\nData Types:")
print(df.dtypes)

# Convert date columns
df["Order Date"] = pd.to_datetime(df["Order Date"])
df["Ship Date"] = pd.to_datetime(df["Ship Date"])

print("\nUpdated Data Types:")
print(df.dtypes)

print("\nColumn Names:")
print(df.columns)