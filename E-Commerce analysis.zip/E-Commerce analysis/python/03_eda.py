import pandas as pd
df = pd.read_csv("../cleaned_data/cleaned_superstore.csv")
import pandas as pd

# Load cleaned dataset
df = pd.read_csv("../cleaned_data/cleaned_superstore.csv")

# Total Sales
total_sales = df["Sales"].sum()
print("Total Sales :", total_sales)

# Total Profit
total_profit = df["Profit"].sum()
print("Total Profit :", total_profit)

# Total Orders
total_orders = df["Order ID"].nunique()
print("Total Orders :", total_orders)

# Total Customers
total_customers = df["Customer ID"].nunique()
print("Total Customers :", total_customers)

# Average Sales
average_sales = df["Sales"].mean()
print("Average Sales :", average_sales)

# Highest Sale
highest_sale = df["Sales"].max()
print("Highest Sale :", highest_sale)

# Lowest Sale
lowest_sale = df["Sales"].min()
print("Lowest Sale :", lowest_sale)
# Sales by Category
category_sales = df.groupby("Category")["Sales"].sum()
print("\nSales by Category:")
print(category_sales)

# Profit by Category
category_profit = df.groupby("Category")["Profit"].sum()
print("\nProfit by Category:")
print(category_profit)

# Sales by Region
region_sales = df.groupby("Region")["Sales"].sum()
print("\nSales by Region:")
print(region_sales)

# Profit by Region
region_profit = df.groupby("Region")["Profit"].sum()
print("\nProfit by Region:")
print(region_profit)

# Sales by Segment
segment_sales = df.groupby("Segment")["Sales"].sum()
print("\nSales by Segment:")
print(segment_sales)

# Top 10 Products
top_products = df.groupby("Product Name")["Sales"].sum().sort_values(ascending=False).head(10)
print("\nTop 10 Products:")
print(top_products)

# Top 10 Customers
top_customers = df.groupby("Customer Name")["Sales"].sum().sort_values(ascending=False).head(10)
print("\nTop 10 Customers:")
print(top_customers)