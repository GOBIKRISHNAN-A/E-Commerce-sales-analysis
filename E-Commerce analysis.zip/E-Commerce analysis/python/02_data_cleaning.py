from pathlib import Path

import pandas as pd

base_dir = Path(__file__).resolve().parent
input_file = base_dir.parent / "Data" / "Sample - Superstore.csv"
output_dir = base_dir.parent / "cleaned_data"
output_dir.mkdir(parents=True, exist_ok=True)

# Load dataset
df = pd.read_csv(input_file, encoding="latin1")

print("Dataset Loaded Successfully!")

# Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Check duplicate rows
print("\nDuplicate Rows:")
print(df.duplicated().sum())

# Remove duplicate rows
df = df.drop_duplicates()

# Check data types
print("\nData Types:")
print(df.dtypes)

# Convert dates
df["Order Date"] = pd.to_datetime(df["Order Date"])
df["Ship Date"] = pd.to_datetime(df["Ship Date"])

# Verify updated data types
print("\nUpdated Data Types:")
print(df.dtypes)

# Save cleaned dataset
df.to_csv(output_dir / "cleaned_superstore.csv", index=False)

print("\nCleaned dataset saved successfully!")